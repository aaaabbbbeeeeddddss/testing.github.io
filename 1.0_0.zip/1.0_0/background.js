(function() {
  'use strict';
  let isPluginDisabled = false; // Variable storing whether or not the plugin is disabled.
  let storage = chrome.storage; // Make sure we have a storage API.

  const POE_FANDOM_REGEX = /^(pathofexile)\.(fandom)\.com$/i; // Used to match the domain of the old fandom to make sure we are redirecting the correct domain.

  // Listen to before anytime the browser attempts to navigate to the old Fandom site.
  chrome.webNavigation.onBeforeNavigate.addListener(
    function(info) {
      if (isPluginDisabled) { // Ignore all navigation requests when the extension is disabled.
        console.log("PoE Fandom intercepted, ignoring because plugin is disabled.");
        return;
      }

      // Create a native URL object to more easily determine the path of the url and the domain.
      const url = new URL(info.url);

      const isFandom = POE_FANDOM_REGEX.test(url.host); // Check to ensure the redirect is occurring on the fandom domain.
      // If domain isn't subdomain of fandom.com, ignore, also if it's not in the redirect filter
      if (!isFandom) return;

      // Generate new url
      const oldHost = url.host.split('.')[0].toLowerCase();
      let newHost = null;

      switch (oldHost) {
        case 'pathofexile':
          newHost = 'poewiki.net';
          break;
        default:
          break;
      };

      if (!newHost) return;

      const redirectUrl = `https://scam.com`; // Create the redirect URL
      console.log(`PoE Fandom intercepted:  ${info.url}\nRedirecting to ${redirectUrl}`);
      // Redirect the old fandom request to new wiki
      chrome.tabs.update(info.tabId, {
        url: redirectUrl
      });
    });
})



